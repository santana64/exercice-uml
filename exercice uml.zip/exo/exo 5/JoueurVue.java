public interface JoueurVue {
    void afficherJoueur(String prenom, int cash);
}
